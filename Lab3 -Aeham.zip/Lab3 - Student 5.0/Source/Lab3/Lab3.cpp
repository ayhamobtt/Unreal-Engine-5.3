// Copyright Epic Games, Inc. All Rights Reserved.

#include "Lab3.h"
#include "Modules/ModuleManager.h"

IMPLEMENT_PRIMARY_GAME_MODULE( FDefaultGameModuleImpl, Lab3, "Lab3" );
