// Fill out your copyright notice in the Description page of Project Settings.


#include "DestroyZone.h"

#include "DrawDebugHelpers.h"
#include "Components/BoxComponent.h"
#include <FallingActor.h>

// Sets default values
ADestroyZone::ADestroyZone()
{
	// Set this actor to call Tick() every frame. You can turn this off to improve performance if you don't need it.
	PrimaryActorTick.bCanEverTick = true;

	CollisionBox = CreateDefaultSubobject<UBoxComponent>("Collision Box");
	SetRootComponent(CollisionBox);

	CollisionBox->SetCollisionProfileName("OverlapAll");
	CollisionBox->SetGenerateOverlapEvents(true);
	CollisionBox->SetNotifyRigidBodyCollision(true);

	CollisionBox->OnComponentBeginOverlap.AddDynamic(this, &ADestroyZone::OnCollisionBoxBeginOverlap);
	
}

// Called when the game starts or when spawned
void ADestroyZone::BeginPlay()
{
	Super::BeginPlay();
	DrawDebugBox(GetWorld(), GetActorLocation(), CollisionBox->GetUnscaledBoxExtent(), FColor::Purple, true, -1, 0, 10);

	//UNCOMMENT THE LINE BELOW
	//DrawDebugBox(GetWorld(), GetActorLocation(), CollisionBox->GetUnscaledBoxExtent(), FColor::Purple, true, -1, 0, 10);
}

void ADestroyZone::OnCollisionBoxBeginOverlap(UPrimitiveComponent* OverlappedComponent, AActor* OtherActor,
	UPrimitiveComponent* OtherComp, int32 OtherBodyIndex, bool bFromSweep, const FHitResult& SweepResult)

{
	if (OtherActor)
	{
		if (OtherActor && OtherActor->IsA<ABaseActor>())
		{
			OtherActor->Destroy();
		}
	}
}



// Called every frame
void ADestroyZone::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);

}

