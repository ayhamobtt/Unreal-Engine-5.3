// Fill out your copyright notice in the Description page of Project Settings.

#include "FallingActor.h"
#include "Components/BoxComponent.h"

AFallingActor::AFallingActor()
{
}

void  AFallingActor::BeginPlay()
{
	Super::BeginPlay();

	// Set the ActorMesh to simulate physics
	if (BoxComponent)
	{
		BoxComponent->SetSimulatePhysics(true);
		ActorMesh->SetSimulatePhysics(false);
	}
}


///////////////




