#include "ActorSpawner.h"
#include "Components/ArrowComponent.h"
#include "FallingActor.h"
// Sets default values
AActorSpawner::AActorSpawner()
{
    // Set this actor to call Tick() every frame. You can turn this off to improve performance if you don't need it.
    PrimaryActorTick.bCanEverTick = true;
    RootComponent = CreateDefaultSubobject<USceneComponent>(TEXT("RootComponent"));

    /* arrow component */
    //CREATE the SpawnPointComponent
    SpawnPointComponent = CreateDefaultSubobject<UArrowComponent>(TEXT("SpawnPoint"));
    //ATTACH the SpawnPointComponent to the RootComponent
    SpawnPointComponent->SetupAttachment(RootComponent);
    //SET the SpawnPointComponent's ArrowSize property to 5.0f
    SpawnPointComponent->ArrowSize = 5.0f;
    //SET SpawnPointComponents Relative Rotation to something like 50.f, 0.f, 0.f
    SpawnPointComponent->SetRelativeRotation(FRotator(00.f, 46.79f, 0.f));
    //SET SpawnPointComponents Relative Location to something like 0.f, 100.f, 0.f
    SpawnPointComponent->SetRelativeLocation(FVector(-380.0f, -160.f, 20.f));
}

// Called when the game starts or when spawned
void AActorSpawner::BeginPlay()
{
    //CALL Super::BeginPlay()
    Super::BeginPlay();
    //START the SpawnTimer, it will call the SpawnActor() function every "SpawnDelay" and it will loop
    GetWorldTimerManager().SetTimer(SpawnTimer, this, &AActorSpawner::SpawnActor, SpawnDelay, true);
}

// Called every frame
void AActorSpawner::Tick(float DeltaTime)
{
    Super::Tick(DeltaTime);

    UE_LOG(LogTemp, Warning, TEXT("ActorSpawner Tick is being called"));
}

void AActorSpawner::SpawnActor()
{
    //IF the FallingActorTemplate NOT EQUAL to nullptr
    if (FallingActorTemplate)
    {
        //DECLARE a variable called World of type const UWorld* and assign it to the return value of GetWorld()
        UWorld* World = GetWorld();
        //IF World is NOT EQUAL to nullptr
        if (World)
        {
            //SETUP the Spawn Parameters using a FActorSpawnParameters object
            FActorSpawnParameters SpawnParams;
            SpawnParams.SpawnCollisionHandlingOverride = ESpawnActorCollisionHandlingMethod::AlwaysSpawn;

            //GET the SpawnTransform from the SpawnPointComponent
            FTransform SpawnTransform = SpawnPointComponent->GetComponentTransform();
            SpawnTransform.AddToTranslation(SpawnPointComponent->GetForwardVector() * 50.0f);

            //SPAWN an instance of FallingActorTemplate at the SpawnTransform from the SpawnPointComponent
            AFallingActor* SpawnedActor = World->SpawnActor<AFallingActor>(FallingActorTemplate, SpawnTransform, SpawnParams);
            if (SpawnedActor)
            {
                // Determine the forward direction
                FVector ForwardDirection = SpawnPointComponent->GetForwardVector();

                // Get the physics component from the SpawnedActor
                UPrimitiveComponent* PhysicsComponent = SpawnedActor->GetPhysicsComponent();

                // Check if the physics component exists and is simulating physics
                if (PhysicsComponent && PhysicsComponent->IsSimulatingPhysics())
                {
                    // Add force to the SpawnedActor's physics component in the direction obtained
                    PhysicsComponent->AddForce(ForwardDirection * ForceToApply, NAME_None, true);

                    // Set a custom OnComponentHit delegate for the physics component
                    PhysicsComponent->OnComponentHit.AddDynamic(this, &AActorSpawner::OnCubeHit);
                }
                }
            }
        }
    }
void AActorSpawner::OnCubeHit(UPrimitiveComponent* HitComponent, AActor* OtherActor,
    UPrimitiveComponent* OtherComp, FVector NormalImpulse,
    const FHitResult& Hit)
{
    // Check if the OtherActor is a destroy zone
    if (OtherActor->ActorHasTag("DestroyZone"))
    {
        // Destroy the cube
        OtherActor->Destroy();
    }
}
    
