// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "BaseActor.h"
#include "FallingActor.generated.h"

/**
 * 
 */
UCLASS()
class LAB3_API AFallingActor : public ABaseActor
{
	GENERATED_BODY()

public:
	AFallingActor();

protected:
	virtual void BeginPlay() override;
};

